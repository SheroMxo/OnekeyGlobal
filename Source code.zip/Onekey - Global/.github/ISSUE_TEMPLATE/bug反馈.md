---
name: Bug反馈
about: 反馈一个虫子（确信）
title: "[BUG]: "
labels: ''
assignees: ''

---

**触发Bug后出现了什么症状**
1.

**如何复现该Bug**
步骤:
1. 

**日志**
复制在这里

**截图**
对程序的完整截图

**系统:**
 - OS: Windows
 - Version: 10
